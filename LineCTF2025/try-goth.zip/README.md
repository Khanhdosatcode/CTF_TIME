# How to run
Simply run `deploy/setup.sh`
Web is deployed at port `9000`

## Publishing
Run `package.sh` to just copy necessary files and compress
Remember to change to the correct flag on real env

## For Players
Zip file in `/public` and desciption in `README.md`

## Troubleshoot
If building `bot` stumbles on errors relating to unsigned repository, just `docker volume prune`.
