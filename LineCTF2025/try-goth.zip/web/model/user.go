package model

import (
	"gorm.io/gorm"
	"golang.org/x/crypto/bcrypt"
)

type User struct {
	gorm.Model
	Username string `gorm:"size:255;not null;unique"`
	Password string `gorm:"size:255;not null"`
	DisplayName string `gorm:"size:255;not null"`
	Status Status `gorm:"size:255;not null"`
	WeatherCode string `gorm:"size:255;not null"`
}

type Status string
const (
	HAPIII			Status = "hapiii"
	SADGE			Status = "sadge"
	MEH				Status = "meh"
	HECKED			Status = "hecked"
	TOUCHING_GRASS	Status = "touching grass"
)


func (user *User) Save() (*User, error) {
	err := DB.Create(&user).Error
	if err != nil {
		return &User{}, err
	}
	return user, nil
}

func (user *User) Update(displayName string, status Status, weatherCode string) error {
	result := DB.Model(user).Updates(User{DisplayName: displayName, Status: status, WeatherCode: weatherCode})
	return result.Error
}

func Register(username, password string) (User, error) {
	user := User{}
	user.Username = username
	hashedPassword, _ := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	user.Password = string(hashedPassword[:])
	savedUser, err := user.Save()
	if err != nil {
		return User{}, err
	}

	return *savedUser, nil
}

func verifyPassword(password, hasedPassword string) error {
	return bcrypt.CompareHashAndPassword([]byte(hasedPassword), []byte(password))
}

func Login(username, password string) (User, error) {
	user := User{}
	err := DB.Model(User{}).Where("username = ?", username).Take(&user).Error

	if err != nil {
		return User{}, err
	}

	err = verifyPassword(password, user.Password)
	if err != nil {
		return User{}, err
	}

	return user, nil
}

func GetUserById(id uint) (User, error) {
	user := User{}
	err := DB.First(&user, id).Error

	if err != nil {
		return User{}, err
	}

	return user, nil
}

func GetUserByUsername(username string) (User, error) {
	user := User{}
	err := DB.Model(User{}).Where("username = ?", username).Take(&user).Error

	if err != nil {
		return User{}, err
	}

	return user, nil
}
