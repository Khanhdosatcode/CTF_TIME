package model

import (
	"fmt"
	"log"
	"time"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"

	"try-goth/config"
)

var DB *gorm.DB

func ConnectDatabase(){
	dsn := fmt.Sprintf(
		"%s:%s@tcp(%s)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		config.GetString("db_user"),
		config.GetString("db_pass"),
		config.GetString("db_url"),
		config.GetString("db_name"),
	)

	retries := 6
	connected := false
	var database *gorm.DB
	var err error
	// mysql takes some time to startup, so...
	for i := 0; i < retries; i++ {
		time.Sleep(10 * time.Second)
		database, err = gorm.Open(mysql.Open(dsn), &gorm.Config{})
		if err == nil {
			connected = true
			break
		}

		log.Printf("Try %d: %s", i, err.Error())
	}

	if !connected {
		log.Printf("database = %+v\nerr = %+v", database, err)
		panic("Cannot connect to database")
	}

	log.Printf("Connected to database")

	database.AutoMigrate(&User{})
	DB = database
}
