const fetchWeather = async () => {
  const defaultWeather = {
    temperature: (69.420 - 32) / 1.8,
    message: "Weather iz naisu",
    alert: "Can't conect to weather server"
  }

  // TODO: Contact Yahoo to allow localhost in CORS

  return defaultWeather;
}
