package controller

import (
	"github.com/gin-gonic/gin"

	"try-goth/middleware"
	"try-goth/service"
	"try-goth/view"
)

func HomeController(g *gin.RouterGroup) {
	g.GET("/", middleware.Authenticated(), home)
	g.GET("/report", middleware.Authenticated(), report)
	g.POST("/report", middleware.Authenticated(), doReport)
	g.POST("/alert", alert)
}

func home(c *gin.Context) {
	user, _ := c.Get("user")
	view.Execute(c, "home", service.CommonUser(user))
}

func report(c *gin.Context) {
	user, _ := c.Get("user")
	view.Execute(c, "report", service.CommonUser(user))
}

func doReport(c *gin.Context) {
	user, _ := c.Get("user")
	message, err := service.Report(c)
	if err != nil {
		view.Alert("danger", err.Error())
	} else {
		view.Alert("success", message)
	}
	view.Execute(c, "report", service.CommonUser(user))
}

func alert(c *gin.Context) {
	view.Execute(c, "alert-empty", nil)
}
