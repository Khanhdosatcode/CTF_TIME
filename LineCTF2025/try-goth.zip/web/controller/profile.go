package controller

import (
	"github.com/gin-gonic/gin"

	"try-goth/view"
	"try-goth/model"
	"try-goth/service"
	"try-goth/middleware"
)

type VisitProfile struct {
	service.Profile
	ViewerName string
}

func ProfileController(g *gin.RouterGroup) {
	g.Use(middleware.Authenticated())

	g.GET("/", profile)
	g.GET("/ssr", profileSSR)
	g.PUT("/", updateProfile)
}

func profile(c *gin.Context) {
	user, found := c.Get("user")
	if !found {
		view.Alert("danger", "Can't find profile information")
		view.Redirect(c, "/")
		return
	}

	if c.Query("username") == "" {
		profile, err := service.GetProfileById(user.(model.User).ID, false)
		if err != nil {
			view.Alert("danger", "Can't find profile information: " + err.Error())
			view.Redirect(c, "/")
			return
		}

		view.Execute(c, "profile", profile)
	} else {
		username := c.Query("username")
		profile, err := service.GetProfileByUsername(username, false)
		if err != nil {
			view.Alert("danger", "Can't find profile information: " + err.Error())
			view.Redirect(c, "/profile")
			return
		}

		visitor := VisitProfile{Profile: profile, ViewerName: user.(model.User).Username}
		view.Execute(c, "visit-profile", visitor)
	}
}

func profileSSR(c *gin.Context) {
	user, found := c.Get("user")
	if !found {
		view.Alert("danger", "Can't find profile information")
		view.Redirect(c, "/")
		return
	}

	var profile service.Profile
	var err error

	if c.Query("username") == "" {
		profile, err = service.GetProfileById(user.(model.User).ID, true)
		if err != nil {
			view.Alert("danger", "Can't find profile information: " + err.Error())
			view.Redirect(c, "/")
			return
		}
	} else {
		username := c.Query("username")
		profile, err = service.GetProfileByUsername(username, true)
		if err != nil {
			view.Alert("danger", "Can't find profile information: " + err.Error())
			view.Redirect(c, "/profile")
			return
		}
	}

	if profile.Weather.Found {
		// Render weather data
		view.Execute(c, "profile-page-ssr", profile)
	} else {
		// Stick to client-side fetch
		view.Execute(c, "empty", nil)
	}
}

func updateProfile(c *gin.Context) {
	err := service.UpdateProfile(c)
	if (err != nil) {
		view.Alert("danger", "Can't update profile: " + err.Error())
	}
	view.Redirect(c, "/profile")
}
