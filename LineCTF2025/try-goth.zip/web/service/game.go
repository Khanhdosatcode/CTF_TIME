package service

import (
	"errors"
	"math/rand"
	"log"

	"try-goth/view"
)

type Cell struct {
	Value int
	Status string
	I, J int
}

type Game struct {
	IsFinish bool
	BombCnt int
	OpenCnt int
	Cells [][]Cell
	IsOpen [][]bool
	IsFlag [][]bool
	Row, Col int
}

var spread [][]int

var game Game

// TODO: Handle sessions
func GetGame() Game {
	log.Println("GetGame")
	return game
}

func Start(row, col, difficulty int) {
	game = Game{
		IsFinish: false,
		BombCnt: 0,
		OpenCnt: 0,
		Row: row,
		Col: col,
		Cells: makeFilledArr(row, col, Cell{0, "success", 0, 0}),
		IsOpen: makeFilledArr(row, col, false),
		IsFlag: makeFilledArr(row, col, false),
	}

	log.Println("Intialized")

	initializeMap(difficulty)
	initializeSpread()
}

func inRange(i, j int) bool {
	return 0 <= i && i < game.Row && 0 <= j && j < game.Col;
}

func Click(i, j int, mode string) (*Cell, string, error) {
	if !inRange(i, j) {
		return nil, "", errors.New("invalid move")
	}

	if game.IsFinish {
		return nil, "", errors.New("nothing can be done")
	}

	if game.IsOpen[i][j] {
		return &game.Cells[i][j], "cell-reveal", errors.New("cell is already opened")
	} else {
		if game.IsFlag[i][j] {
			if mode == "flag" {
				game.IsFlag[i][j] = false
				return &game.Cells[i][j], "cell", nil
			} else {
				return &game.Cells[i][j], "cell-flag", errors.New("cell is already flagged")
			}
		} else {
			if mode == "flag" {
				game.IsFlag[i][j] = true
				return &game.Cells[i][j], "cell-flag", nil
			} else if mode == "reveal" {
				reveal(i, j)
				var err error
				if game.Cells[i][j].Value == -1 {
					game.IsFinish = true
					err = errors.New("skill issue")
				}
				if game.Cells[i][j].Value == 0 {
					for _, dir := range spread {
						revealAdj(i + dir[0], j + dir[1])
					}
				}
				return &game.Cells[i][j], "cell-reveal", err
			} else {
				return nil, "", errors.New("invalid mode")
			}
		}
	}
}

func reveal(i, j int) {
	game.IsOpen[i][j] = true
	game.OpenCnt += 1
	if game.OpenCnt == game.Row * game.Col - game.BombCnt {
		view.Alert("success", "Very cool, such W")
		game.IsFinish = true
	}
}

func revealAdj(i, j int) {
	if !inRange(i, j) || game.IsOpen[i][j] || game.IsFlag[i][j]{
		return
	}

	reveal(i, j)
	view.Add("cell-reveal-oob", game.Cells[i][j])
	if game.Cells[i][j].Value == 0 {
		for _, dir := range spread {
			revealAdj(i + dir[0], j + dir[1])
		}
	}
}

func makeFilledArr[T any](n int, m int, value T) [][]T {
	arr := make([][]T, n)
	for i := 0; i < n; i++ {
		arr[i] = make([]T, m)
		for j := 0; j < m; j++ {
			arr[i][j] = value
		}
	}
	return arr
}

func initializeMap(difficulty int) {
	for i := 0; i < game.Row; i++ {
		for j := 0; j < game.Col; j++ {
			game.Cells[i][j].I = i
			game.Cells[i][j].J = j
		}
	}

	game.BombCnt = (game.Row * game.Col) * difficulty / 100

	for cnt := 0; cnt < game.BombCnt; cnt++ {
		for {
			i := rand.Intn(game.Row)
			j := rand.Intn(game.Col)
			if game.Cells[i][j].Value >= 0 {
				game.Cells[i][j].Value = -1
				game.Cells[i][j].Status = "danger"

				for ii := max(i - 1, 0); ii < min(i + 2, game.Row); ii++ {
					for jj := max(j - 1, 0); jj < min(j + 2, game.Col); jj++ {
						if (ii == i && jj == j) || (game.Cells[ii][jj].Value == -1) {
							continue
						}

						game.Cells[ii][jj].Value += 1
					}
				}
				break
			}
		}
	}
}

func initializeSpread() {
	if len(spread) != 0 {
		return
	}

	for i := -1; i <= 1; i++ {
		for j := -1; j <= 1; j++ {
			if i == 0 && j == 0 {
				continue
			}
			spread = append(spread, []int{i, j})
		}
	}
}
