package service

import (
	"errors"
	"regexp"
	"strings"

	"github.com/gin-gonic/gin"

	"try-goth/model"
	"try-goth/view"
)

type Weather struct {
	Temperature float64 // in celcius
	Message string // sunny, raining, etc
	Found bool // in case weather code is incorrect
}

type Profile struct {
	User model.User
	Weather
}

func f2c(f float64) float64 {
	return (f - 32) / 1.8
}

func fetchWeather(code string) Weather {
	// TODO: Make agreement to get direct feed from weather satelite
	codeRegex := regexp.MustCompile("^[0-9]+$")
	if codeRegex.FindString(code) == "" {
		view.Alert("danger", "Cannot fetch weather code \"" + code  +"\"")
		return Weather{Temperature: f2c(69.420), Message: "Weather iz not found", Found: false}
	} else {
		return Weather{Temperature: f2c(69.420), Message: "Weather iz naisu", Found: true}
	}
}

func getProfile(user model.User, weather bool) Profile {
	profile := Profile{User: user}
	if (weather) {
		profile.Weather = fetchWeather(user.WeatherCode)
	}

	return profile
}

func GetProfileById(id uint, weather bool) (Profile, error) {
	user, err := model.GetUserById(id)
	if err != nil {
		return Profile{}, errors.New("user id not found")
	}

	return getProfile(user, weather), nil
}

func GetProfileByUsername(username string, weather bool) (Profile, error) {
	user, err := model.GetUserByUsername(username)
	if err != nil {
		return Profile{}, errors.New("username not found")
	}

	return getProfile(user, weather), nil
}

func validate(status, displayName, weatherCode string) bool {
	blacklisted := "\"';:<>()\\#$%-?&" // idk ChatGPT said this will work
	buf := ""
	idx := []int{}
	buf += "status"
	idx = append(idx, len(buf))
	buf += status
	idx = append(idx, len(buf))
	buf += "displayName"
	idx = append(idx, len(buf))
	buf += displayName
	idx = append(idx, len(buf))
	buf += "weatherCode"
	idx = append(idx, len(buf))
	buf += weatherCode
	idx = append(idx, len(buf))

	lowerBuf := strings.ToLower(buf)
	upperBuf := strings.ToUpper(buf)
	if len(buf) != len(lowerBuf) || len(upperBuf) != len(lowerBuf) {
		return false
	}

	buf = lowerBuf
	for i := 0; i < 6; i += 2 {
		if strings.ContainsAny(buf[idx[i]:idx[i+1]], blacklisted) {
			return false
		}
		if strings.Contains(buf[idx[i]:idx[i+1]], "bot") {
			return false
		}
	}

	return true
}

func UpdateProfile(c *gin.Context) (error) {
	userData, found := c.Get("user")
	if !found {
		return errors.New("user id not found")
	}

	user := userData.(model.User)

	status := model.Status(c.PostForm("status"))
	displayName := c.PostForm("displayName")
	weatherCode := c.PostForm("weatherCode")

	if !validate(string(status), displayName, weatherCode) {
		return errors.New("no hecker")
	}

	err := user.Update(displayName, status, weatherCode)
	if err != nil {
		return errors.New("can't update user info: " + err.Error())

	}

	return nil
}
