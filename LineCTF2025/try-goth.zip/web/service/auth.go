package service

import (
	"errors"
	"strings"

	"try-goth/config"
	"try-goth/model"
)

type LoginResult struct {
	UserId uint
}

type RegisterResult struct {
	UserId uint
}

type CommonUserData struct {
	Username string
}

func CommonUser(user any) (CommonUserData) {
	return CommonUserData{Username: user.(model.User).Username}
}

func Login(username, password string) (LoginResult, error) {
	user, err := model.Login(username, password)
	if err != nil {
		return LoginResult{}, errors.New("username or password is incorrect")
	}

	return LoginResult{UserId: user.ID}, nil
}

func Register(username, password, token string) (RegisterResult, error) {

	if strings.Contains(username, "bot") && token != config.GetString("bot_token") {
		return RegisterResult{}, errors.New("no you aren't")
	}

	user, err := model.Register(username, password)
	if err != nil {
		return RegisterResult{}, errors.New("can't register using this username")
	}

	// default value
	user.Update(user.Username, model.HAPIII, "1252431")

	return RegisterResult{UserId: user.ID}, nil
}

func GetUserById(userId any) (model.User, error) {
	if userId == nil {
		return model.User{}, errors.New("invalid user id")
	}

	id := userId.(uint)

	user, err := model.GetUserById(id)
	if err != nil {
		return model.User{}, errors.New("can't find user with id")
	}

	return user, nil
}
