const express = require('express');
const puppeteer = require('puppeteer');
const { randomBytes } = require('crypto');

const router = express.Router();

var queue = {}

const wait = (id) => {
  const lastTime = queue[id] || 0;
  const curTime = new Date().getTime()
  console.log(id, lastTime, curTime)
  if (curTime - lastTime >= 60 * 1000) { // 1req/min
    queue[id] = curTime
    return true;
  }
  return false;
}

router.post('/bot/report', async (req, res) => {
  const { url, id } = req.body;
  console.log(url, id)

  if (!wait(id)) {
    return res.status(400).send("Plz wait for a minute and try again");
  }

  visit(url);
  return res.status(200).send("I'll gladly check it out for you");
});

const sleep = async (ms) => new Promise(resolve => setTimeout(resolve, ms));

const rand = () => 'bot-' + randomBytes(34).toString('hex');
var username;
var password;

const visit = async (url) => {
  try {
    console.log(`Launching into ${url}`)
    const browser = await puppeteer.launch({
      headless: "true",
      executablePath: `/usr/bin/google-chrome`,
      args: [
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--disable-setuid-sandbox",
        "--no-sandbox",
        '--ignore-certificate-errors'
      ],
      product: "chrome"
    });

    let page = (await browser.pages())[0];
    if (!username) {
      username = rand();
      password = rand();

      await page.goto(`${process.env.BOT_URL}/auth/register`);
      await page.type('[name="username"]', username);
      await page.type('[name="password"]', password);
      await page.evaluate(
        token => document.querySelector('input[name="token"]').value = token,
        process.env.BOT_TOKEN
      )
      await page.click('[id="registerBtn"]');
      await page.waitForNavigation();
    }

    await page.goto(`${process.env.BOT_URL}/auth/login`);
    await page.type('[name="username"]', username);
    await page.type('[name="password"]', password);
    await page.click('[id="loginBtn"]');
    await page.waitForNavigation();

    await page.goto(`${process.env.BOT_URL}/profile`);
    await page.evaluate(
      flag => document.querySelector('input[name="displayName"]').value = flag,
      process.env.BOT_FLAG
    )
    await page.click('[id="profileBtn"]');
    await page.waitForNavigation();

    // Go to URL of user and stay at this page a little while
    await page.goto(url);
    await sleep(10000);

    await browser.close();
    console.log(`Closed browser`)
  } catch (e) {
    console.error(e);
    try {
      await browser.close();
      console.log(`Closed browser`)
    } catch (e) { }
  }
}

module.exports = router;
