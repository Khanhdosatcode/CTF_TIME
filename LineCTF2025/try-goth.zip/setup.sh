#!/bin/bash

CHALLENGE_PORT="9000"
SECRET=$(xxd -u -l 32 -c 32 -p /dev/urandom)
FLAG="FLAG{test}"
WEB_URL="http:\/\/web:9000"
BOT_URL="http:\/\/bot:9001"
BOT_TOKEN=$(xxd -u -l 32 -c 32 -p /dev/urandom)
MYSQL_URL="mysql:3306"
MYSQL_ROOT=$(xxd -u -l 32 -c 32 -p /dev/urandom)
MYSQL_DB="try-goth"
MYSQL_USER=$(xxd -u -l 16 -c 16 -p /dev/urandom)
MYSQL_PASS=$(xxd -u -l 32 -c 32 -p /dev/urandom)

cat .env.example \
| sed "s/<CHALLENGE_PORT>/$CHALLENGE_PORT/" \
| sed "s/<WEB_SECRET>/$SECRET/" \
| sed "s/<WEB_BOT_URL>/$BOT_URL/" \
| sed "s/<WEB_BOT_TOKEN>/$BOT_TOKEN/" \
| sed "s/<WEB_DB_URL>/$MYSQL_URL/" \
| sed "s/<WEB_DB_NAME>/$MYSQL_DB/" \
| sed "s/<WEB_DB_USER>/$MYSQL_USER/" \
| sed "s/<WEB_DB_PASS>/$MYSQL_PASS/" \
| sed "s/<BOT_FLAG>/$FLAG/" \
| sed "s/<BOT_TOKEN>/$BOT_TOKEN/" \
| sed "s/<BOT_URL>/$WEB_URL/" \
| sed "s/<MYSQL_ROOT>/$MYSQL_ROOT/" \
| sed "s/<MYSQL_DB>/$MYSQL_DB/" \
| sed "s/<MYSQL_USER>/$MYSQL_USER/" \
| sed "s/<MYSQL_PASS>/$MYSQL_PASS/" \
> .env

docker compose -p try-goth down && docker compose -p try-goth up --build -d
