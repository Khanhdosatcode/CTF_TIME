exports.handleSuccess = (req, res, next) => {
  res.success = function(data) {
    this.status(200).json({
      success: true,
      data
    })
  }

  next()
}

exports.handleError = (err, req, res, next) => {
  if (res.headersSent) {
    return next(err)
  }

  console.error(err);
  res.status(500).json({ success: false })
}
