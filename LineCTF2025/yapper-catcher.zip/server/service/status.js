const { Status, testDB } = require('../model/index.js');
const { randomId, decrypt } = require('../utils.js');

exports.getStatus = async (req, res, next) => {
  const statusId = req.param('id');
  if (!statusId) {
    return next()
  }
  const status = await Status.getStatus(statusId);
  if (!status) {
    return next(new Error(`Can't find status with id ${statusId}`));
  }

  status.content = status.content.map(content => {
    content.userSize = parseInt(content.user.split(':')[2].length / 2);
    content.quoteSize = parseInt(content.quote.split(':')[2].length / 2);
    return content;
  });

  res.render('status', { status });
}

exports.newStatus = async (req, res, next) => {
  const user = req.param('user');
  res.set('Cache-Control', 'no-cache');
  res.render('status-new', { user });
}

exports.createStatus = async (req, res, next) => {
  let { user, quote, passcode } = req.body;
  let statusId;
  do {
    statusId = await randomId();
  }
  while(await Status.conflictId(statusId))

  if (!passcode) {
    passcode = await randomId();
  }

  try {
    await Status.createStatus(statusId, user, quote, passcode);
  }
  catch (e) {
    console.error(e);
    return next("Cannot create new status");
  }

  return res.redirect(`/${statusId}`);
}

exports.updateStatus = async (req, res, next) => {
  const id = req.param('id');
  if (!id) {
    return next();
  }

  const { user, quote } = req.body;
  try {
    await Status.updateStatus(id, user, quote);
  }
  catch (e) {
    console.error(e);
    return next(`Cannot update status with id ${id}`)
  }

  return res.redirect(`/${id}?random=${Math.random()}`);
}

exports.decryptStatus = async (req, res, next) => {
  let { user, quote, passcode } = req.body;
  try {
    user = await decrypt(user, passcode);
    quote = await decrypt(quote, passcode);
    return res.success({ user, quote });
  }
  catch (e) {
    console.error(e);
    return next(`Cannot decrypt quote with this passcode`);
  }
}
