const {
  scryptSync,
  randomFillSync,
  createCipheriv,
  createDecipheriv,
  createHmac,
  getCipherInfo
} = require('node:crypto');

const algorithm = 'aes-256-cbc';
const {
  ivLength,
  keyLength
} = getCipherInfo(algorithm);

const hmacKey = process.env.SERVER_HMAC_KEY || 'ahihi';

exports.randomId = async () => {
  const buf = Buffer.alloc(16, 0);
  await randomFillSync(buf);

  return buf.toString('hex');
}

exports.encrypt = async (content, passcode) => {
  const key = await scryptSync(passcode, 'NaCl', keyLength);
  const iv = Buffer.alloc(ivLength, 0);
  await randomFillSync(iv);

  const cipher = createCipheriv(algorithm, key, iv);
  let encrypted = cipher.update(content, 'utf8', 'hex');
  encrypted += cipher.final('hex');

  const hmac = createHmac('sha-256', hmacKey);
  hmac.update(encrypted);
  const digest = hmac.digest('hex');

  return [digest, iv.toString('hex'), encrypted].join(':');
}

exports.decrypt = async (encrypted, passcode) => {
  const key = await scryptSync(passcode, 'NaCl', keyLength);
  let [digest, iv, cipherText] = encrypted.split(':');
  iv = Buffer.from(iv, 'hex');

  const hmac = createHmac('sha-256', hmacKey);
  hmac.update(cipherText);
  const validDigest = hmac.digest('hex');
  if (digest !== validDigest) {
    throw Error('Invalid HMAC');
  }

  const decipher = createDecipheriv(algorithm, key, iv);
  let decrypted = decipher.update(cipherText, 'hex', 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}
