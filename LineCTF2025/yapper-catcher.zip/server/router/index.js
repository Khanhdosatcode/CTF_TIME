const { Router } = require('express');
const { status, yapper, debug } = require('../service/index.js');

const router = Router();

// status
router.get('/', status.getStatus, status.newStatus);
router.get('/:id([a-f0-9]{32})', status.getStatus);
router.post('/', status.updateStatus, status.createStatus);
router.post('/decrypt', status.decryptStatus);

// bot
router.get('/yapper', yapper.getYapper);

// debug
// router.get('/debug', debug.testEncryption);

module.exports = router;
