const { db } = require('./db.js');
const { encrypt, decrypt } = require('../utils.js');

const passcode_key = process.env.SERVER_PASSKEY || 'ahihi';

exports.getStatus = async (id) => {
  let status = await db.collection('status').findOne({ id });
  return status;
};

exports.conflictId = async (id) => {
  const status = await db.collection('status').findOne({ id });
  return !!status;
};

exports.createStatus = async (id, user, quote, passcode) => {
  user = await encrypt(user, passcode);
  quote = await encrypt(quote, passcode);
  passcode = await encrypt(passcode, passcode_key);
  await db.collection('status').insertOne({
    id,
    content: [{ user, quote }],
    passcode,
    createdAt: new Date().toString(),
  })
};

exports.updateStatus = async(id, user, quote) => {
  const status = await db.collection('status').findOne({ id });
  if (!status) {
    throw Error(`Status with id ${id} doesn't exist`);
  }

  passcode = await decrypt(status.passcode, passcode_key);
  user = await encrypt(user, passcode);
  quote = await encrypt(quote, passcode);

  await db.collection('status').updateOne(
    { id },
    { $push: { content: { user, quote } } }
  )
};
