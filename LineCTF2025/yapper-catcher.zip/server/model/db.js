const { MongoClient } = require('mongodb');

const user = process.env.DB_USER || 'user';
const password = process.env.DB_PASSWORD || 'password';
const url = process.env.DB_URL || 'localhost:27017';
const uri = `mongodb://${user}:${password}@${url}`;

const client = new MongoClient(uri);
const db = client.db('db');

const testDB = async () => {
  await client.connect();
  await client.db("admin").command({ ping: 1 });
  console.log('DB is running and connected!');
};

module.exports = {
  db,
  testDB
}
