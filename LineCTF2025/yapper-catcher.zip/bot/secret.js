const checkSecret = (body) => {
  const { a, b, c } = body;
  return (a === 0.2) && (b === 0.1) && (c === 0.3) && (a + b === c);
}

module.exports = checkSecret;
