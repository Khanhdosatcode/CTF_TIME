const axios = require('axios');

const verify = async (body) => {
  const params = new URLSearchParams();
  params.append('secret', process.env.BOT_CAPTCHA_SECRET);
  params.append('response', body["g-recaptcha-response"]);
  const res = await axios.post('https://www.google.com/recaptcha/api/siteverify', params)

  return res.data.success
}

module.exports = verify;
