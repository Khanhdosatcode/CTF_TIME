# How to run
Simply run `./setup.sh`
Web is deployed at port `9001` (Defined by `CHALLENGE_PORT` in `setup.sh`)

## For Players
Zip file in `/public` and desciption in `README.md`

## Troubleshoot
If building `bot` stumbles on errors relating to unsigned repository, just `docker volume prune`.
