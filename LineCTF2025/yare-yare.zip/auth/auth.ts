class Account {
    username: string;
    password: string;
    name: string;

    constructor(username: string, password: string, name: string) {
        this.username = username;
        this.password = password;
        this.name = name;
    }

    toDisplay(): Account {
        return new Account(this.username, '', this.name);
    }
}

class Session {
    sessions: Record<string, string>;
    logs: string[];

    constructor(_sessions: Record<string, string> = {}) {
        this.sessions = _sessions;
        this.logs = [];
    }

    add(username: string): string {
        const token = Math.random().toString();
        this.sessions[token] = username;
        return token;
    }

    _add(username: string, token: string): string {
        this.sessions[token] = username;
        return token;
    }

    get(token: string): Account {
        token = token.replaceAll(/[^0-9\-\.]/g, '');
        const username = this.sessions[token];
        if (!username) {
            throw new Error("No session");
        }
        const account = accounts.find((account: Account) => account.username === username);
        if (!account) {
            throw new Error("Wot?");
        }

        return account.toDisplay();
    }

    clear(token: string) {
        token = token.replaceAll(/[^0-9\.]/g, '');
        if (this.sessions[token]) {
            delete this.sessions[token];

            this.logs.push(token);
            while (this.logs.length > 10) {
                this.logs.shift();
            }
        }
        else {
            throw new Error("Nope");
        }
    }
}

const accounts: Account[] = [];
const session: Session = new Session();

export function login(username: string, password: string): string {
    const account = accounts.find(async (account: Account) => {
        return account.username === username
            && (await Bun.password.verify(password, account.password));
    });
    if (!account) {
        return "-2";
    }

    if (username === process.env.ADMIN_USER) {
        return session.add(username);
    }

    // TODO
    return session._add(username, '-1');
}

export async function addAccount(username: string, password: string, name: string) {
    const account = accounts.find((account: Account) => account.username === username);
    if (account) {
        throw new Error("account existed");
    }

    const hashedPassword = await Bun.password.hash(password);
    accounts.push(new Account(username, hashedPassword, name));
}

export function getSession(token: string): Account {
    return session.get(token);
}

export function clearSession(token: string) {
    return session.clear(token);
}

export function getLogs(): string[] {
    return session.logs;
}
