<template>
  <span>{{ text }}</span>
</template>

<script lang="ts">
    export default {
        props:
        {
            text: {
                type: String,
                require: true
            }
        }
    }
</script>
