<template>
  <code
    class="text-primary"
    :class="{ 'bg-primary-subtle': selected }"
    >
    {{ text }}
  </code>
</template>

<script lang="ts">
    export default {
        props:
        {
            text: {
                type: String,
                require: true
            },
            selected: {
                type: Boolean,
                require: true
            }
        }
    }
</script>

<style scoped>
    code {
        transition: background-color 0.2s ease-in-out;
    }
    code:hover {
        background-color: rgba(0, 0, 100, 0.1);
    }
</style>
