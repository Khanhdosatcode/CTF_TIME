const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const fs = require('fs');
const morgan = require("morgan");
const { serializePayload } = require('./utils')

const app = express();

app.use(bodyParser.urlencoded({ extended: false, limit: '20kb' }));
app.use(morgan('combined'));

let template;

const render = (res, data) => {
  let { content, auth } = data;
  let response = template;
  if (content) {
    response = response.replace('{{content-here}}', content);
  }
  if (auth) {
    response = response.replace('{{username}}', auth.username);
    response = response.replace('{{name}}', auth.name);
  }

  res.set('Content-Type', 'text/html');
  return res.status(200).send(response);
}

const mimeType = (path) => {
  if (path.endsWith('.js')) {
    return 'text/javascript';
  }
  if (path.endsWith('.json')) {
    return 'application/json';
  }
  if (path.endsWith('.css')) {
    return 'text/css';
  }
}

const fetchSession = async () => {
  res = await axios.get(process.env.BRIDGE_HOST + '/' + serializePayload({ action: 'session' }));
  return res.data.session;
}

app.get('/', (req, res) => {
  return render(res, {});
})

app.post('/', async (req, res) => {
  const { regex, text } = req.body;
  const session = await fetchSession();
  const payload = {
    action: 'infiltrate',
    session,
    regex,
    text,
  };
  const response = await axios.get(process.env.BRIDGE_HOST + '/' + serializePayload(payload));

  return render(res, response.data);
});

app.get('/_nuxt/*', async (req, res) => {
  const path = req.originalUrl;
  if (path.endsWith('/')) {
    return res.status(400).send('???');
  }

  const type = mimeType(path);
  if (!type) {
    return res.status(400).send('???');
  }

  res.set('Content-Type', type);
  const response = await axios.get(process.env.BRIDGE_HOST + '/' + serializePayload({ action: 'static', path }));
  return res.status(200).send(response.data.content);
})

app.get('/logs', async (req, res) => {
  response = await axios.get(process.env.BRIDGE_HOST + '/' + serializePayload({ action: 'logs' }));
  return res.json(response.data.logs)
})

const port = process.env.SERVER_PORT || 3000;
app.listen(port, async () => {
  template = await fs.readFileSync('panel.html').toString();
})
