# How to run
`./setup.sh` to deploy
Web is deployed at port `9002` (Defined by `CHALLENGE_PORT` in `setup.sh`)

`./dev.sh` to start the development env

## Publishing
Run `package.sh` to just copy necessary files and compress
Remember to change to the correct flag on real env

## For Players
Zip file in `/public` and desciption in `README.md`
