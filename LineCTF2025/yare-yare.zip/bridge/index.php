<?php
error_reporting(0);

$uri = $_SERVER['REQUEST_URI'];

$path = parse_url($_SERVER['REQUEST_URI'])['path'];
$payload = parse_payload(substr($path, 1));

function parse_payload($serialized) {
    $params = explode(";", base64_decode($serialized), 4);
    $data = [];
    foreach ($params as $param) {
        $parts = explode("=", $param);
        if (!$data[$parts[0]]) {
            $data[$parts[0]] = $parts[1];
        }
    }

    return $data;
}

function json($data) {
    header('Content-Type: application/json; charset=utf-8');
    die(json_encode($data));
}

if ($payload['action'] === 'session') {
    $creds = [
        'username' => getenv('SPY_USER'),
        'password' => getenv('SPY_PASS')
    ];

    $ch = curl_init(getenv('AUTH_HOST') . '/login');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($creds));
    $res = curl_exec($ch);
    curl_close($ch);


    if ($res !== false) {
        json([
            'session' => $res
        ]);
    }
    else {
        json([
            'session' => ""
        ]);
    }
}
if ($payload['action'] === 'logs') {
    $ch = curl_init(getenv('AUTH_HOST') . '/logs');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $content = curl_exec($ch);
    curl_close($ch);

    if ($content === false) {
        json([
            'logs' => [],
        ]);
    }

    json([
        'logs' => json_decode($content, true)['logs'],
    ]);
}
if ($payload['action'] === 'static') {
    $ch = curl_init(getenv('INTERNAL_HOST'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, getenv('INTERNAL_HOST') . $payload['path']);
    $content = curl_exec($ch);
    curl_close($ch);

    if (strpos($content, 'FLAG{') !== false) {
        json([
            'content' => 'Mine now, thx'
        ]);
    }

    json([
        'content' => $content
    ]);
}
if ($payload['action'] === 'infiltrate') {
    $data = [
        'regex' => $payload['regex'],
        'text' => $payload['text'],
    ];

    $ch = curl_init(getenv('INTERNAL_HOST'));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_URL, getenv('INTERNAL_HOST') . '?' . http_build_query($data));
    curl_setopt($ch, CURLOPT_COOKIE, "session={$payload['session']}");
    $content = curl_exec($ch);
    curl_close($ch);

    if ($content === false) {
        json([
            'content' => "Something's wrong..."
        ]);
    }

    if (strpos($content, 'FLAG{') !== false) {
        json([
            'content' => 'Mine now, thx'
        ]);
    }

    $ch = curl_init(getenv('AUTH_HOST') . '/info');
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_COOKIE, "session={$payload['session']}");
    $auth = curl_exec($ch);
    curl_close($ch);

    if ($auth === false) {
        json([
            'content' => "Something's wrong..."
        ]);
    }

    json([
        'content' => $content,
        'auth' => json_decode($auth, true)
    ]);
}

json([
    'content' => 'Unsupported action'
])

?>
