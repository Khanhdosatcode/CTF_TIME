class quote2{
    constructor(){
    }

    all(){
        return {
            "Ngô Bá Khá": ["https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcROKacAtwDaMGIFRVwgCHLC3soqrqzwwaOyWQ&usqp=CAU","Ôi bạn ơi!"],
            "Huấn Hoa Hồng": ["https://kenhtamly.net/uploads/dongtoico/huanhoahong/tieusuhuanhoahong1.png","Ra xã hội làm ăn bươn chải, liều thì ăn nhiều, không liều thì ăn ít."],
            "Đầu Cắt Moi": ["https://s.memehay.com/files/posts/20200906/dau-cat-moi-gian-do-nguoi-mat-day-dau-hoi-54840e9f0ec8be34abcb72c8de9b5790.jpg","Nói ít thôi!"],
            "Gia Tùng": ["https://s.memehay.com/files/posts/20200902/ohhh-tung-bung-no-tac-gia-cau-noi-vai-lon-luon-dau-cat-moi-5207836be391922f0fbba28c3060b05b.jpg","Đợi xỉa cái răng đã rồi nói chuyện tiếp."]
        }
    }

}

let instance = new quote2()
exports.default = instance;
module.exports = exports['default'];