var puppeteer = require('puppeteer');
var crypto = require('node:crypto')
const FLAG = process.env.FLAG ?? "justCTF{FAKE}";

const isValidUUID = (text) => {
	const uuidRegexp =
		/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

	return uuidRegexp.test(text);
};

let browser;
const report = async (data) => {
	if (!isValidUUID(data)) {
		throw new Error("Ivalid UUID format");
	}
    
    if(browser){
        await browser.close();
        await new Promise((resolve) => setTimeout(resolve, 2_000));
        console.log("terminated ongoing job");
    }
    try {
        browser = await puppeteer.launch({
            browser: "chrome",
            headless: "new",
            args: [
                "--disable-gpu",
                "--no-sandbox",
                "--js-flags=--noexpose_wasm,--jitless",
            ]
        });

        const page = await browser.newPage();
        await page.goto(`http://localhost:3000/register`);
        await page.type('#username', crypto.randomUUID());
        await page.type('#password', crypto.randomUUID());
        await page.click("button")
        await new Promise((resolve) => setTimeout(resolve, 1000));
        await page.type('#content', FLAG);
        await page.click("button")
        await new Promise((resolve) => setTimeout(resolve, 1000));

        await page.close()

        const userPage = await browser.newPage();
        await userPage.goto('http://localhost:3000/note?id='+data)

        await new Promise((resolve) => setTimeout(resolve, 10_000));

    } catch(e){
        console.log(e)
    } finally {
        await browser.close();
        browser = null;
    }
};

module.exports = report