#!/bin/sh

set -e

vault server -dev &


export VAULT_ADDR="http://localhost:8200"
export VAULT_TOKEN="$VAULT_DEV_ROOT_TOKEN_ID"

until curl -sf "${VAULT_ADDR}/sys/health" > /dev/null; do
    sleep 1
done


vault secrets enable -path user-data -version=2 kv
vault secrets enable -path admin-data -version=2 kv

vault kv put -mount admin-data flag secret="$(cat /app/flag.txt)"
vault kv put -mount user-data something foo="bar"

vault auth enable aws
vault write auth/aws/config/client \
    access_key=${AWS_ACCESS_KEY} \
    secret_key=${AWS_SECRET_KEY} \
    region=${AWS_REGION}

vault policy write user-policy /app/user-policy.hcl
vault write auth/aws/role/user-role \
     auth_type=iam \
     bound_iam_principal_arn=arn:aws:iam::${AWS_ACCOUNT_ID}:role/user-role \
     policies=user-policy

vault policy write admin-policy /app/admin-policy.hcl
vault write auth/aws/role/admin-role \
     auth_type=iam \
     bound_subnet_id=${ADMIN_SUBNET} \
     policies=admin-policy \
     inferred_entity_type=ec2_instance \
     inferred_aws_region=${AWS_REGION}

vault write sys/quotas/rate-limit/global-rate rate=1

sleep infinity