package main

import (
	"bytes"
	"crypto/rand"
	"encoding/json"
	"encoding/xml"
	"fmt"
	"io"
	"net/http"
	"os"
	"regexp"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/sts"

	"github.com/hashicorp/go-secure-stdlib/awsutil"
)

var vaultUrl = "http://vault:8200"
var roleArn string
var sessionLog []string

type GetCallerIdentityResponse struct {
	XMLName                 xml.Name                `xml:"GetCallerIdentityResponse"`
	GetCallerIdentityResult GetCallerIdentityResult `xml:"GetCallerIdentityResult"`
}

type GetCallerIdentityResult struct {
	Arn     string `xml:"Arn"`
	UserId  string `xml:"UserId"`
	Account string `xml:"Account"`
}

func validateSessionName(sessionName string) error {
	match, _ := regexp.MatchString("^[a-f0-9]+$", sessionName)
	if !match {
		return fmt.Errorf("invalid session name")
	}
	return nil
}

func initVars() error {
	roleArn = os.Getenv("ROLE_ARN")
	if roleArn == "" {
		return fmt.Errorf("error: ROLE_ARN environment variable is not set")
	}
	sessionLog = make([]string, 0)

	return nil
}

func main() {
	err := initVars()
	if err != nil {
		fmt.Printf("Error initializing variables: %s\n", err)
		os.Exit(1)
	}

	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "Got no identity? Feel free to grab mine!")
	})
	http.HandleFunc("/getSecret", func(w http.ResponseWriter, r *http.Request) {
		path := r.URL.Query().Get("path")
		if path == "" {
			http.Error(w, "Missing 'path' query parameter", http.StatusBadRequest)
			return
		}
		if !(len(path) >= len("user-data/data/") && path[:len("user-data/data/")] == "user-data/data/") &&
			!(len(path) >= len("admin-data/data/") && path[:len("admin-data/data/")] == "admin-data/data/") {
			http.Error(w, "Invalid 'path' query parameter", http.StatusForbidden)
			return
		}
		token := r.Header.Get("X-Vault-Token")
		if token == "" {
			http.Error(w, "Missing X-Vault-Token header", http.StatusBadRequest)
			return
		}
		getUrl := fmt.Sprintf("%s/v1/%s", vaultUrl, path)

		req, err := http.NewRequest("GET", getUrl, nil)
		if err != nil {
			http.Error(w, fmt.Sprintf("Error creating request: %s", err), http.StatusInternalServerError)
			return
		}
		req.Header.Set("X-Vault-Token", token)

		client := &http.Client{}
		resp, err := client.Do(req)
		if err != nil {
			http.Error(w, fmt.Sprintf("Error making request to Vault: %s", err), http.StatusInternalServerError)
			return
		}
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			http.Error(w, fmt.Sprintf("Error: received status code %d", resp.StatusCode), http.StatusInternalServerError)
			return
		}

		var body struct {
			Data struct {
				Data map[string]interface{} `json:"data"`
			} `json:"data"`
			Errors []string `json:"errors"`
		}
		if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
			http.Error(w, fmt.Sprintf("Error decoding response: %s", err), http.StatusInternalServerError)
			return
		}
		if body.Errors != nil {
			http.Error(w, fmt.Sprintf("Error in response: %v", body.Errors), http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		if err := json.NewEncoder(w).Encode(body.Data.Data); err != nil {
			http.Error(w, fmt.Sprintf("Error encoding data: %s", err), http.StatusInternalServerError)
			return
		}
	})

	http.HandleFunc("/getIdentity", func(w http.ResponseWriter, r *http.Request) {
		sessionName := r.URL.Query().Get("session_name")
		if sessionName == "" {
			bytes := make([]byte, 16)
			rand.Read(bytes)
			sessionName = fmt.Sprintf("%032x", bytes)
		}

		if err = validateSessionName(sessionName); err != nil {
			http.Error(w, "Invalid session name", http.StatusForbidden)
			return
		}

		sess, err := session.NewSession(&aws.Config{
			Region: aws.String("eu-west-1"),
		})
		if err != nil {
			http.Error(w, "Error creating AWS session", http.StatusInternalServerError)
		}

		stsClient := sts.New(sess)

		if len(sessionName) > 2048 {
			http.Error(w, "Session name is too long", http.StatusBadRequest)
			return
		}
		input := &sts.AssumeRoleInput{
			RoleArn:         aws.String(roleArn),
			RoleSessionName: aws.String(sessionName),
		}

		result, err := stsClient.AssumeRole(input)
		if err != nil {
			http.Error(w, "Error assuming role", http.StatusInternalServerError)
		}
		if result.Credentials == nil {
			http.Error(w, "Assume role failed", http.StatusInternalServerError)
			return
		}

		creds, err := awsutil.RetrieveCreds(
			*result.Credentials.AccessKeyId,
			*result.Credentials.SecretAccessKey,
			*result.Credentials.SessionToken,
			nil,
		)
		if err != nil {
			http.Error(w, "Error while retrieving credentials", http.StatusInternalServerError)
			return
		}

		loginData, err := awsutil.GenerateLoginData(creds, "", "us-east-1", nil)
		if err != nil {
			http.Error(w, "Error while generating login data", http.StatusInternalServerError)
			return
		}
		if loginData == nil {
			http.Error(w, "Got nil response from GenerateLoginData", http.StatusInternalServerError)
			return
		}

		w.Header().Set("Content-Type", "application/json")
		if err := json.NewEncoder(w).Encode(loginData); err != nil {
			http.Error(w, fmt.Sprintf("Error encoding login data: %s", err), http.StatusInternalServerError)
			return
		}
	})

	http.HandleFunc("/getToken", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Invalid request method, only POST is allowed", http.StatusMethodNotAllowed)
			return
		}

		var requestData map[string]string
		if err := json.NewDecoder(r.Body).Decode(&requestData); err != nil {
			http.Error(w, "POST data is not correct JSON", http.StatusBadRequest)
			return
		}

		awsAuthUrl := fmt.Sprintf("%s/v1/auth/aws/login", vaultUrl)
		jsonData, err := json.Marshal(requestData)
		if err != nil {
			http.Error(w, fmt.Sprintf("Error encoding JSON: %s", err), http.StatusInternalServerError)
			return
		}

		resp, err := http.Post(awsAuthUrl, "application/json", bytes.NewBuffer(jsonData))
		if err != nil {
			http.Error(w, fmt.Sprintf("Error making request to Vault: %s", err), http.StatusInternalServerError)
			return
		}
		if resp.StatusCode != http.StatusOK {
			data, _ := io.ReadAll(resp.Body)
			fmt.Fprintln(w, string(data))
			http.Error(w, fmt.Sprintf("Error: received status code %d", resp.StatusCode), http.StatusInternalServerError)
			return
		}

		var body struct {
			Auth struct {
				ClientToken string `json:"client_token"`
			} `json:"auth"`
			Errors []string `json:"errors"`
		}
		if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
			http.Error(w, fmt.Sprintf("Error decoding response: %s", err), http.StatusInternalServerError)
			return
		}
		if body.Errors != nil {
			http.Error(w, fmt.Sprintf("Error in response: %v", body.Errors), http.StatusInternalServerError)
			return
		}

		response := map[string]string{
			"token": body.Auth.ClientToken,
		}

		w.Header().Set("Content-Type", "application/json")
		if err := json.NewEncoder(w).Encode(response); err != nil {
			http.Error(w, fmt.Sprintf("Error encoding response: %s", err), http.StatusInternalServerError)
			return
		}
	})

	if err := http.ListenAndServe(":8080", nil); err != nil {
		fmt.Printf("Error starting server: %s\n", err)
	}
}
