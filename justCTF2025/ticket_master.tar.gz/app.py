#!/usr/bin/env python

from flask import Flask, render_template, request, jsonify
from ticket import generate_ticket, load_ticket

from wtforms import Form, StringField, IntegerField, FieldList
from wtforms.validators import DataRequired, NumberRange, AnyOf, Length

import random, base64
from os import environ

app = Flask(__name__)

GENERATED_TICKETS = []
SEAT_ROWS = list("ABCDEFX")
SEAT_NUMS = list("1234567")
SELLER_KEY = random.randbytes(16).hex()
print(f"[*] Generate special tickets using key: {SELLER_KEY}")

class TicketData(Form):
    number = IntegerField(validators=[DataRequired()], default=lambda: random.randint(10000, 99999))
    section = StringField(validators=[DataRequired(), AnyOf(["PLAYER", "VIP", "BACKSTAGE"])], default="PLAYER")
    seat = FieldList(
        StringField(validators=[DataRequired(), Length(min=1, max=1)]),
        IntegerField(validators=[DataRequired(), NumberRange(min=1, max=7)])
    )
    type = StringField(validators=[DataRequired(), AnyOf(["FREE", "PAID", "ORGANIZER"])])

@app.route("/", methods=["GET"])
def index():
    return render_template("index.html")

@app.route("/generate", methods=["POST"])
def generate():
    if not request.is_json:
        return jsonify({"error": "Invalid JSON"}), 400

    data = request.get_json()
    ticket_data = TicketData(data=data)

    if len(ticket_data.seat) == 0:
        ticket_data.seat.append_entry().data = random.choice(SEAT_ROWS)
        ticket_data.seat.append_entry().data = random.choice(SEAT_NUMS)

    if not any(key in data for key in ["number", "section", "seat", "type"]):
        ticket_data.number.data = 2137
        ticket_data.type.data = "FREE"
    elif "seller_key" in data and data["seller_key"] == SELLER_KEY:
        ticket_data.type.data = "PAID"
    else:
        return jsonify({"error": "You're not allowed to generate that ticket!"}), 422

    if not ticket_data.validate() or ticket_data.data["seat"][0] not in SEAT_ROWS or ticket_data.data["seat"][1] not in SEAT_NUMS:
        return jsonify({"error": "Something went wrong.."}), 500

    data = ticket_data.data
    seat = f"{data['section']}/{''.join(data['seat'])}"
    if seat in GENERATED_TICKETS:
        return jsonify({"error": "Sorry! Someone just bought this seat before you!"}), 410

    try:
        ticket = generate_ticket(
            data["number"],
            seat,
            data["type"]
        )
        GENERATED_TICKETS.append(seat)
    except Exception as ex:
        return jsonify({"error": ex}), 500

    return jsonify({"ticket": base64.b64encode(ticket).decode()}), 200

@app.route("/enter", methods=["POST"])
def enter():
    if not request.is_json:
        return jsonify({"error": "Invalid JSON"}), 400

    data = request.get_json()

    if "img" not in data:
        return jsonify({"error": "Missing 'img' parameter"}), 400

    try:
        ticket_number, seat, type = load_ticket(base64.b64decode(data['img']))

        return jsonify({
                "ticket_number": ticket_number,
                "seat": seat,
                "message": f"Welcome!\nEnjoy {type} ticket!" if type in ["FREE", "PAID"] else environ["FLAG"]
            }), 200
    except Exception as ex:
        return jsonify({"error": str(ex)}), 500

if __name__ == "__main__":
    app.run()
